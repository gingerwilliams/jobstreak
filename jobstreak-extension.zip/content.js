const createDate = () => {
    // Returns date in MM-DD-YYYY format
    const date = new Date();
    return `${date.getMonth() + 1}-${date.getDate()}-${date.getFullYear()}`;
};

const scrapeJobs = (selectors) => {
    const jobTypeFilter = ['Remote', "On-site", "Hybrid", ];

    return Array.from(document.querySelectorAll(selectors.jobSelector)).map((el) => {
        const jobTypeText = el.innerText;
        // const isMatch = jobTypeFilter.some(type => jobTypeText.includes(type));
        // if (!isMatch) return;
        const title = el.querySelector(selectors.title)?.innerText ?? 'No title';
        const company = el.querySelector(selectors.company)?.innerText ?? 'No Company Name';
        const location = el.querySelector(selectors.location)?.innerText ?? 'No Location';
        const id = selectors.id(el) || "No ID";
        const url = selectors.url(el) || 'No URL';
        return {
            title,
            id,
            company,
            location,
            url,
            status: "saved",
            createdAt: createDate(),
            type: jobTypeFilter.find(type => jobTypeText.includes(type)) ?? '',};
    });
    
};

const Constants =  {
    // job boards
    LI: "https://www.linkedin.com",
    LI_COLLECTIONS: "/jobs/collections/recommended/",
    LI_SEARCH_RESULTS: "/jobs/search-results/",

    INDEED: "https://www.indeed.com/",
    INDEED_Q: "q-",
    INDEED_L: "l-",
    INDEED_JOBS_Q: "jobs?q=",
    INDEED_JOBS_L: "jobs?l=",
    INDEED_JOBSEEKER: "?from=gnav",

    GD: "https://www.glassdoor.com",
    GD_JOBS: "/Job/",

    ZIP: "https://www.ziprecruiter.com",
    ZIP_JOBS: "/jobs-search?",

    DICE: "https://www.dice.com",
    DICE_JOBS: "/jobs",
    DICE_RECCOMMENDED: "/jobs/recommended-jobs",

    WELL: "https://wellfound.com",
    WELL_JOBS: "/jobs",
};

const dice = () => {
    console.log("Dice board executed");
    const { DICE, DICE_JOBS, DICE_RECCOMMENDED} = Constants;
    // since we have a white list we dont need this condition
    window.document.documentURI.includes(`${DICE}${DICE_JOBS}`) ||
        window.document.documentURI.includes(`${DICE}${DICE_RECCOMMENDED}`);

    const selectors = {
        id: (el) => {
            const url = el.querySelector('a').getAttribute('href');
            const id = url.slice(url.lastIndexOf('/') + 1);
            console.log(`Dice ID: ${id}`);
            return id;
        },
        jobSelector:'[role*="listitem"]',
        title:'.content a',
        company: '.header p',
        location:'.content > span > div > div:first-child p',
        url: (el) => {
            const url =  el.querySelector('a').getAttribute('href');
            console.log(`Dice URL: ${url}`);
            return url
        }
    };

    return scrapeJobs(selectors)
};

const glassdoor = () => {
    console.log("Glassdoor board executed");
    const { GD, GD_JOBS } = Constants;
    // since we have a white list we dont need this condition
    window.document.documentURI.includes(`${GD}${GD_JOBS}`);

    const selectors = {
        id: (el) => el.getAttribute("selectors.id"),
        jobSelector:'[class*="JobsList_jobListItem"]',
        title:'[class*="JobCard_jobTitle"]',
        company:'[class*="EmployerProfile_compactEmployerName"]',
        location:'[class*="JobCard_location"]',
        url: (el) => {
            return el.querySelector("a")?.getAttribute("href") || 'No URL' 
        },
    };

    return scrapeJobs(selectors)
};

const { INDEED, INDEED_L, INDEED_Q, INDEED_JOBSEEKER, INDEED_JOBS_L, INDEED_JOBS_Q } = Constants;

const jobTypeFilter$1 = ['Remote', "On-site", "Hybrid", ];

const indeed = () => {
    console.log("Indeed board executed");
    if (
        window.document.documentURI.includes(`${INDEED}${INDEED_Q}`) || 
        window.document.documentURI.includes(`${INDEED}${INDEED_L}`) || 
        window.document.documentURI.includes(`${INDEED}${INDEED_JOBS_L}`) || 
        window.document.documentURI.includes(`${INDEED}${INDEED_JOBS_Q}`) || 
        window.document.documentURI.includes(`${INDEED}${INDEED_JOBSEEKER}`) || 
        window.document.documentURI === INDEED
    ) {
        const jobSelector = '.job_seen_beacon';

        return Array.from(document.querySelectorAll(jobSelector)).map((el) => {
            const jobTypeText = el.innerText;
            // const isMatch = jobTypeFilter.some(type => jobTypeText.includes(type));
            // if (!isMatch) return;

            const title = el.querySelector(".jobTitle span")?.innerText ?? 'No title';
            const company = el.querySelector('.company_location span')?.innerText.trim() ?? 'No company';
            const location = el.querySelector(`.company_location div div[data-testid]`)?.innerText.trim() ?? 'No location';
            const id = el.querySelector("a").getAttribute("id");
            const pathname = el.querySelector("a").getAttribute("href");
            const url = INDEED + pathname.slice(1);
            const createdAt = createDate(); // remove
            const status = "saved"; // remove

            return {
                id,
                title,
                createdAt,
                company,
                status,
                location,
                url,
                type: jobTypeFilter$1.find(type => jobTypeText.includes(type)) ?? '',
            };
        });
    }
};

const { LI, LI_SEARCH_RESULTS, LI_COLLECTIONS } = Constants;

const jobTypeFilter = ['Remote', "On-site", "Hybrid", ]; // Customize this

const linkedIn = () => {
    console.log("linkedIn board executed");
    if (window.document.location.pathname === LI_SEARCH_RESULTS) {
        const jobSelector = '.job-card-job-posting-card-wrapper__card-link';
    
        return Array.from(document.querySelectorAll(jobSelector)).map((el) => {
            const jobTypeText = el.innerText;
            // const isMatch = jobTypeFilter.some(type => jobTypeText.includes(type));
            // if (!isMatch) return;

            const title = el.querySelector("strong")?.innerText ?? 'No title';
            const company = el.querySelector('.artdeco-entity-lockup__subtitle > div')?.innerText.trim() ?? 'No company';
            const location = el.querySelector('.artdeco-entity-lockup__caption > div')?.innerText.trim() ?? 'No location';
            const id = getParams(el.href);
            const createdAt = createDate();
            const status = "saved";

            return {
                id,
                title,
                createdAt,
                status,
                company,
                location,
                type: jobTypeFilter.find(type => jobTypeText.includes(type)) ?? '',
                url: LI + "/jobs/view/" + id
            };
        });
    } else if (window.document.location.pathname === LI_COLLECTIONS) {
        const jobSelector = '.job-card-container';

        return Array.from(document.querySelectorAll(jobSelector)).map((el) => {
            const jobTypeText = el.innerText;
            // const isMatch = jobTypeFilter.some(type => jobTypeText.includes(type));
            // if (!isMatch) return;

            const title = el.querySelector(".job-card-list__title--link strong")?.innerText ?? 'No title';
            const company = el.querySelector('.artdeco-entity-lockup__subtitle > span')?.innerText.trim() ?? 'No company';
            const location = el.querySelector('.artdeco-entity-lockup__caption span')?.innerText.trim() ?? 'No location';
            const id = el.getAttribute("data-job-id");
            const createdAt = createDate;
            const status = "saved";

            return {
                id,
                title,
                company,
                createdAt,
                status,
                location,
                type: jobTypeFilter.find(type => jobTypeText.includes(type)) ?? '',
                url: LI + "/jobs/view/" + id
            };
        });
    }
};

function getParams(url) {
    const searchParams = new URLSearchParams(url);
    let id;

    for (const param of searchParams){
        if (param[0].includes("https://www.linkedin.com")) {
            id = param[1];
        } 
    }
   return id
}

// function getParams(url) {
//   try {
//     const idMatch = url.match(/\/(\d+)(?:[/?]|$)/);
//     return idMatch ? idMatch[1] : null;
//   } catch (e) {
//     return null;
//   }
// }

const zipRecruiter = () => {
    console.log("Zip board executed");
    const { ZIP, ZIP_JOBS} = Constants;
    // since we have a white list we dont need this condition
    window.document.documentURI.includes(`${ZIP}${ZIP_JOBS}`);

    const selectors = {
        id: (el) => el.getAttribute("id"),
        jobSelector:'[class*="job_result_two_pane"]',
        title:'h2 button',
        company:'[data-testid*="job-card-company"]',
        location:'[data-testid*="job-card-location"]',
        url: (el) => {
            const { origin } = window.document.location;
            const jobId = el.getAttribute("id").slice(9);
            return (origin + ZIP_JOBS + "lvk=" + jobId) || 'No URL'; // construct the URL from the job ID
        }
    };

    return scrapeJobs(selectors)
};

const wellfound = () => {
    console.log("Wellfound board executed");
    const { WELL, WELL_JOBS } = Constants;
    const selectors = {
        id: (el) => {
            const jobEndpoint = el.querySelector('[class*="styles_jobLink"]').getAttribute("href");
            const slice = jobEndpoint.slice(jobEndpoint.lastIndexOf('/') + 1);
            console.log(`Wellfound ID: ${slice}`);
            return slice;

        },
        jobSelector:'[data-test*="StartupResult"]',
        title:'[class*="styles_titleBar__"] span',
        company:'h2',
        location:'[class*="styles_location__"]',
        url: (el) => {
            const jobId = el.querySelector('[class*="styles_jobLink"]').getAttribute("href");
            return `${WELL}${jobId}`;
        }
    };

    return scrapeJobs(selectors)
};

/**
 * Greenhouse, Lever
 * RemoteOK,
 * Robert Half
 * @returns 
 */


const jobBoard = () => {
    const hostname = window.document.location.hostname;
    
    const jobBoardUrls = {
        "www.dice.com": dice,
        "www.glassdoor.com": glassdoor,
        "www.indeed.com": indeed,
        "www.linkedin.com": linkedIn,
        "www.ziprecruiter.com": zipRecruiter,
        "wellfound.com": wellfound
    };

    return jobBoardUrls[hostname];
};

console.log("JobStreak content script loaded");

// Sample selector for a job listing (adjust per site)
// Selector for LinkedIn job listings
// TODO: create a whitelist for available boards
function captureJobListings() {
  	console.log("captureJobListings executed");

  	const board = jobBoard(); // switch object for job boards
	const jobs = board() || [];
	
  	if (jobs.length > 0) {
    	chrome.storage.local.get(['jobStreak'], (result) => {
      		const existing = result.jobStreak || [];
			const existingIds = new Set(existing.map(j => j.id));
      		const newJobs = jobs.filter(j => !existingIds.has(j.id));

			const appendJobs = [...existing, ...newJobs];

			chrome.storage.local.set({ jobStreak: appendJobs }, () => {
				console.log(`Saved ${jobs.length} new job(s), total: ${appendJobs.length}`);
			});
    	});
		return true;
  	}
	return false;
}

// "Save Job to JobStreak" sent messege
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'extractAndSaveJob') {
    captureJobListings();
    sendResponse({ status: 'initiated' });
  }
});
