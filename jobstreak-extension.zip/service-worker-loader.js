import 'http://localhost:5173/@vite/env';
import 'http://localhost:5173/@crx/client-worker';
import 'http://localhost:5173/src/background.js';
